import React from 'react'
import './Verify.css'
import { useSearchParams } from 'react-router-dom'

const Verify = () => {

    const [serachParams, setSearchParams] = useSearchParams();
    const success = serachParams.get('success');
    const orderId = serachParams.get('orderId');
    console.log(success,orderId);
  return (
    <div>
      
    </div>
  )
}

export default Verify
