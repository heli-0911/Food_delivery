import { createContext, useEffect, useState } from "react";
import axios from "axios";

export const StoreContext = createContext(null);

const StoreContextProvider = (props) => {
    const [cartItems, setCartItems] = useState({});
    const url = "http://localhost:9748";
    const [token, setToken] = useState("");
    const [food_list, setFoodList] = useState([]);

    // Function to add an item to the cart
    const addToCart = async (itemId) => {
        if (!itemId) {
            console.error("addToCart called with undefined itemId");
            return;
        }

        setCartItems((prev) => ({
            ...prev,
            [itemId]: prev[itemId] ? prev[itemId] + 1 : 1,
        }));

        if (token) {
            try {
                await axios.post(url + "/api/cart/add", { itemId }, { headers: { token } });
            } catch (error) {
                console.error("Error adding to cart:", error);
            }
        }
    };

    // Function to remove an item from the cart 
    const removeFromCart = async (itemId) => {
        if (!itemId || !cartItems[itemId]) {
            console.error("removeFromCart called with invalid itemId");
            return;
        }

        setCartItems((prev) => {
            const newCart = { ...prev };
            if (newCart[itemId] > 1) {
                newCart[itemId] -= 1;
            } else {
                delete newCart[itemId];
            }
            return newCart;
        });

        if (token) {
            try {
                await axios.post(url + "/api/cart/remove", { itemId }, { headers: { token } });
            } catch (error) {
                console.error("Error removing from cart:", error);
            }
        }
    };

    // Function to calculate the total cart amount
    const getTotalCartAmount = () => {
        let totalAmount = 0;
        for (const item in cartItems) {
            if (cartItems[item] > 0) {
                let itemInfo = food_list.find((product) => product._id === item);
                if (!itemInfo) {
                    console.warn(`Product not found in food_list for ID: ${item}`);
                    continue;
                }
                totalAmount += itemInfo.price * cartItems[item];
            }
        }
        return totalAmount;
    };

    // Function to fetch food list from API
    const fetchFoodList = async () => {
        try {
            const response = await axios.get(url + "/api/food/list");
            setFoodList(response.data.data);
        } catch (error) {
            console.error("Error fetching food list:", error);
        }
    };

    // Function to load cart data from API
    const loadCartData = async (token) => {
        try {
            const response = await axios.post(url + "/api/cart/get", {}, { headers: { token } });
            setCartItems(response.data.cartData || {}); // Ensure cartItems is always an object
        } catch (error) {
            console.error("Error loading cart data:", error);
            setCartItems({}); // Fallback to empty object
        }
    };

    // Fetch food list and load cart data on mount
    useEffect(() => {
        async function loadData() {
            try {
                await fetchFoodList();
                if (localStorage.getItem("token")) {
                    const storedToken = localStorage.getItem("token");
                    setToken(storedToken);
                    console.log("Loading cart data for token:", storedToken);
                    await loadCartData(storedToken);
                }
            } catch (error) {
                console.error("Error in loadData:", error);
            }
        }
        loadData();
    }, []);

    // Context value to provide to components
    const contextValue = {
        food_list,
        cartItems,
        setCartItems,
        addToCart,
        removeFromCart,
        getTotalCartAmount,
        url,
        token,
        setToken,
    };

    return (
        <StoreContext.Provider value={contextValue}>
            {props.children}
        </StoreContext.Provider>
    );
};

export default StoreContextProvider
